<?php $__env->startSection('title', '| Lets Talk'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-4 col-lg-offset-4">
            <h1 id="greetings" class="text-danger text-center">Hello, <span id="username"><?php echo e($user); ?></span></h1>
            <div id="chat-window" class="col-lg-12"></div>
            <div class="col-lg-12">
                <div id="typing-status" class="col-lg-12" style="padding: 15px"></div>
                <input type="text" class="form-control" name="message" id="text" placeholder="Enter message..." onblur="notTyping()">
            </div>
        </div>
    </div>

    <script>
        var token = '<?php echo e(Session::token()); ?>';
        var urlSend = '<?php echo e(route('send')); ?>';
        var urlTyping = '<?php echo e(route('typing')); ?>';
        var urlNotTyping = '<?php echo e(route('notTyping')); ?>';
        var urlRetrieve = '<?php echo e(route('retrieve')); ?>';
        var urlTypingStatus = '<?php echo e(route('typingStatus')); ?>'
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>