<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Chuka Connect <?php echo $__env->yieldContent('title'); ?></title>
    
    <!-- bootstrap css -->
    <?php echo Html::style('/css/bootstrap.min.css'); ?>

    
    <!-- custom css -->
    <?php echo Html::style('/css/main.css'); ?>

    <?php echo Html::style('/css/chat.css'); ?>

    
    
</head>
<body>
   <?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- scripts -->
    <?php echo Html::script('/js/jquery.js'); ?>

    <?php echo Html::script('/js/bootstrap.min.js'); ?>

    <?php echo Html::script('/js/app.js'); ?>

    <?php echo Html::script('/js/chat.js'); ?>

</body>
</html>