<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
        
    public function index(Request $request)
    {
        //validate data
        $this->validate($request, array(
            'email' => 'required',
            'password' => 'required',
        ));
        if(Auth::attempt(['email' => $request['email'], 'password' => $request['password']])){
            return redirect()->route('dashboard');
        }
        
        return redirect()->back();
    }
    
    public function getLogout()
    {
        Auth::logout();
        return redirect()->route('home');
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //validate data
        $this->validate($request, array(
            'email' => 'required|email|unique:users',
            'first_name' => 'required|max:120',
            'password' => 'required|min:4',
        ));
        
        //store in the db
        $user = new user;
        
        $user->email = $request->email;
        $user->first_name = $request->first_name;
        $user->password = bcrypt($request->password);
        
        $user->save();
        
        Auth::login($user);
        
        //redirect
        return redirect()->route('dashboard');
    }

    public  function getAccount()
    {
        $user = Auth::user();
        return view('account', ['user' => $user]);
    }

    public function postSaveAccount(Request $request)
    {
        $this->validate($request, [
            'first_name' => 'required|max:120'
        ]);

        $user = Auth::user();
        $user->first_name = $request['first_name'];
        $user->update();

        $file = $request->file('image');
        $filename = $request['first_name'] . '-' . $user->id . '.jpg';

        if($file){
            Storage::disk('local')->put($filename, File::get($file));
        }

        return redirect()->route('account');
    }

    public  function getUserImage($filename)
    {
        $file = Storage::disk('local')->get($filename);
        return new Response($file, 200);
    }

//    public function getHeader()
//    {
//        $user = Auth::user();
//
//        return view('includes.header', ['appUser' => $user]);
//    }
}
