<?php

namespace App\Http\Controllers;

use App\Chat;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;

class ChatController extends Controller
{
    public function getChat()
    {
        $user = Auth::user()->first_name;
        return view('chat',['user' => $user]);
    }

    public function sendMessage()
    {
        $username = Input::get('username');
        $text = Input::get('text');

        $chat = new Chat();
        $chat->sender_username = $username;
        $chat->message = $text;
        $chat->save();
    }

    public function typing()
    {

    }

    public function notTyping()
    {

    }

    public function retrieveMessages()
    {
        $username = Input::get('username');

        $message = Chat::where('sender_username', '!=', $username)->where('read', '=', false)->first();

        if(count($message) > 0)
        {
            $message->read = true;
            $message->save();
            return $message->message;
        }
    }

    function typingStatus()
    {
        $username = Input::get('username');

        $chat = ChatMessage::find(1);

        if($$chat->user1 == $username)
        {
            if($chat->user2_is_typing)
            {
                return $chat->user2;
            }
        }
        else
        {
            if($chat->user1_is_typing)
            {
                return $chat->user1;
            }
        }
    }
}
