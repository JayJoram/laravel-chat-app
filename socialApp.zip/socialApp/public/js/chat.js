$(document).ready(function () {
    var username;
    pullData();
    username = $('#username').html();
    console.log(username);

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $(document).keyup(function (e) {
        if(e.keyCode == 13){
            console.log("Enter Pressed");
            sendMessage();
        }
        else{
             isTyping();
        }
    });
    
    function pullData() {
        retrieveChatMessages();
        retrieveTypingStatus;
        setTimeout(pullData, 3000);
    }
    
    function  retrieveChatMessages() {
        $.ajax({
            method: 'POST',
            url: urlRetrieve,
            data: {
                _token: token,
                username: username
            }
        })
            .done(function (data) {
                if(data.length > 0)
                {
                    $('#chat-window').append('<br><div>' + data +'</div><br>');
                }
            });
    }
    
    function retrieveTypingStatus() {
        $.ajax({
            method: 'POST',
            url: urlTypingStatus,
            data:{
                _token: token,
                username: username
            }
        })
            .done(function (username) {
                if(username.length > 0)
                {
                    $('#typing-status').html(username + 'is typing....');
                }
                else{
                    $('#typing-status').html('');
                }
            });
    }
    
    function sendMessage() {
        var text;
        text = $('#text').val();
        console.log(text);

        if(text.length > 0){
            $.ajax({
                method: 'POST',
                url: urlSend,
                data: {
                    token:token, text: text, username: username
                }
            })
                .done(function () {
                    $('#chat-window').append('<br><div style="text-align: right;">' + text + '</div><br>');
                    $('#text').val('');
                    notTyping();
                });
        }
    }

    function isTyping() {
        $.ajax({
            method: 'POST',
            url: urlTyping,
            data: {
                username:username
            }
        });
    }

    function notTyping() {
        $.ajax({
            method: 'POST',
            url: urlNotTyping,
            data: {username: username}
        });
    }
});