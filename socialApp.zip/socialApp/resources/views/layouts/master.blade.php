<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Chuka Connect @yield('title')</title>
    
    <!-- bootstrap css -->
    {!! Html::style('/css/bootstrap.min.css') !!}
    
    <!-- custom css -->
    {!! Html::style('/css/main.css') !!}
    {!! Html::style('/css/chat.css') !!}
    
    
</head>
<body>
   @include('includes.header')
    <div class="container">
        @yield('content')
    </div>
    <!-- scripts -->
    {!! Html::script('/js/jquery.js') !!}
    {!! Html::script('/js/bootstrap.min.js') !!}
    {!! Html::script('/js/app.js') !!}
    {!! Html::script('/js/chat.js') !!}
</body>
</html>