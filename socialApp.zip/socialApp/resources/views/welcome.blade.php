@extends('layouts.master')

@section('title', ' | Welcome')

@section('content')
      @include('includes.message-block')
       <div class="row">
       <!-- sign up -->
        <div class="col-md-6">
            <h1 class="text-center"><strong>Sign Up</strong></h1>
            <form action="{{ route('signup') }}" method="post">
                <div class="form-group {{ $errors->has('email') ? 'has-error' : '' }}">
                    <label for="email">Email Address</label>
                    <input type="email" class="form-control" name="email" id="email" value=" {{ Request::old('email') }}">
                </div>
                <div class="form-group {{ $errors->has('first_name') ? 'has-error' : '' }}">
                    <label for="first-name">Username</label>
                    <input type="text" class="form-control" name="first_name" id="first_name" value= "{{ Request::old('first_name') }}">
                </div>
                <div class="form-group {{ $errors->has('password') ? 'has-error' : '' }}">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" name="password" id="password" value= "{{ Request::old('password') }}">
                </div>
                <button type="submit" class="btn btn-primary">Sign Up</button>
                <input type="hidden" name="_token" value="{{ Session::token() }}">
            </form>
        </div>
        
        <!-- sign in -->
        <div class="col-md-6">
            <h1 class="text-center"><strong>Sign In</strong></h1>
            <form action="{{ route('signin' )}}" method="post">
                <div class="form-group {{ $errors->has('email') ? 'has-error' : '' }}">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" name="email" id="email" value= "{{ Request::old('email') }}">
                </div>
                <div class="form-group {{ $errors->has('password') ? 'has-error' : '' }}">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" name="password" id="password" value= "{{ Request::old('password') }}">
                </div>
                <button type="submit" class="btn btn-primary">Sign In</button>
                <input type="hidden" name="_token" value="{{ Session::token() }}">
            </form>
        </div>
    </div>
    
    
@endsection