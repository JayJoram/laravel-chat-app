@extends('layouts.master')

@section('title', ' | Welcome')

@section('content')
    <div class="row">
       <!-- sign up -->
        <div class="col-md-6">
            <h1 class="text-center"><strong>Sign Up</strong></h1>
            {!!! Form::open(array('route' => 'signup.store', 'method' => 'post' )) !!}
                 <div class="form-group">
                     {{ Form::label('email', 'Your Email') }}
                     {{ Form::email('email', null, array('class' => 'form-control', 'id' => 'email' )) }}
                 </div>
                
                <div class="form-group">
                    {{ Form::label('first_name', 'Your First Name') }}
                    {{ Form::text('first_name', null, array('class' => 'form-control', 'id' => 'first_name')) }}
                </div>
                <div class="form-group">
                    {{ Form::label('password', 'Your Password') }}
                    {{ Form::password('password', array('class' => 'form-control', 'id' => 'password')) }}
                </div>
                {{ Form::submit('Sign Up', array('class' => 'btn btn-primary btn-lg')) }}
                {{ Form::token() }}
            {!! Form::close() !!}
        </div>
        
        <!-- sign in -->
        <div class="col-md-6">
            <h1 class="text-center"><strong>Sign In</strong></h1>
            {!!! Form::open(array('method' => 'post' )) !!}
                 <div class="form-group">
                     {{ Form::label('email', 'Your Email') }}
                     {{ Form::email('email', null, array('class' => 'form-control', 'id' => 'email' )) }}
                 </div>
                 
                <div class="form-group">
                    {{ Form::label('password', 'Your Password') }}
                    {{ Form::password('password', array('class' => 'form-control', 'id' => 'password')) }}
                </div>
                {{ Form::submit('Sign Up', array('class' => 'btn btn-primary btn-lg')) }}
                {{ Form::token() }}
            {!! Form::close() !!}
        </div>
    </div>
    
    
@endsection
