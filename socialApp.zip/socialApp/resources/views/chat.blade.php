@extends('layouts.master')

@section('title', '| Lets Talk')

@section('content')
    <div class="row">
        <div class="col-lg-4 col-lg-offset-4">
            <h1 id="greetings" class="text-danger text-center">Hello, <span id="username">{{ $user }}</span></h1>
            <div id="chat-window" class="col-lg-12"></div>
            <div class="col-lg-12">
                <div id="typing-status" class="col-lg-12" style="padding: 15px"></div>
                <input type="text" class="form-control" name="message" id="text" placeholder="Enter message..." onblur="notTyping()">
            </div>
        </div>
    </div>

    <script>
        var token = '{{ Session::token() }}';
        var urlSend = '{{ route('send') }}';
        var urlTyping = '{{ route('typing') }}';
        var urlNotTyping = '{{ route('notTyping') }}';
        var urlRetrieve = '{{route('retrieve')}}';
        var urlTypingStatus = '{{ route('typingStatus') }}'
    </script>
@endsection